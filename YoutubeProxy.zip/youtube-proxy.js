(function () {
    'use strict';

    var host = '{host}';
    var hostkey = host.replace('http://', '').replace('https://', '');

    function account(url) {
        url = url + '';
        if (url.indexOf('account_email=') == -1) {
            var email = Lampa.Storage.get('account_email');
            if (email) url = Lampa.Utils.addUrlComponent(url, 'account_email=' + encodeURIComponent(email));
        }
        if (url.indexOf('uid=') == -1) {
            var uid = Lampa.Storage.get('lampac_unic_id', '');
            if (uid) url = Lampa.Utils.addUrlComponent(url, 'uid=' + encodeURIComponent(uid));
        }
        if (url.indexOf('nws_id=') == -1 && window.rch_nws && window.rch_nws[hostkey]) {
            var nws_id = window.rch_nws[hostkey].connectionId || '';
            if (nws_id) url = Lampa.Utils.addUrlComponent(url, 'nws_id=' + encodeURIComponent(nws_id));
        }
        return url;
    }

    function getTrailersMenu(videos, lang) {
        lang = lang || 'ru';

        var items = videos.map(function (element) {
            var date = Lampa.Utils.parseTime(element.published_at).full;
            var proxyPath = host + '/youtube/' + element.key;

            return {
                fullTitle: element.name,
                title: Lampa.Utils.shortText(element.name, 50),
                subtitle: (element.official ? Lampa.Lang.translate('full_trailer_official') : Lampa.Lang.translate('full_trailer_no_official')) + ' - ' + date,
                id: element.key,
                code: element.iso_639_1,
                time: new Date(element.published_at).getTime(),
                url: account(account(host + '/youtube/video.mp4?vid=' + element.key)),
                icon: '<img class="size-youtube" src="' + account(host + '/youtube/img.jpg?vid=' + element.key) + '" />',
                template: 'selectbox_icon'
            };
        });

        items.sort((a, b) => { return a.time > b.time ? -1 : a.time < b.time ? 1 : 0 });

        var userLang = items.filter(function (n) { return n.code == lang });
        var engLang = items.filter(function(n) { return n.code == 'en' && userLang.indexOf(n) === -1 });
        var result = [];

        if (userLang.length) {
            result = result.concat(userLang);
        }

        if (result.length && engLang.length) {
            result.push({
                title: Lampa.Lang.translate('more'),
                separator: true
            });
        }

        result = result.concat(engLang);

        return result;
    }

    function start() {
        if (window.youtube_proxy) return;
        window.youtube_proxy = {
            type: 'video',
            version: '{version}',
            name: 'YouTube Proxy',
            description: 'Proxying YouTube trailers and thumbnails',
            author: 'levende'
        }

        Lampa.Manifest.plugins = window.youtube_proxy;

        var geo = {geo};

        if (Array.isArray(geo) && geo.length && geo.indexOf('{country}') === -1) return;

        Lampa.Listener.follow('full',
            function (e) {
                if (e.type !== 'complite') return;
                if (!e.data || !e.data.videos || !Array.isArray(e.data.videos.results)) return;

                var yotubeVideos = e.data.videos.results.filter(function (video) {
                    return video.site && video.site.toLowerCase() === "youtube";
                });

                if (!yotubeVideos.length) return;

                var trailerButton = e.object.activity.render().find('.view--trailer');
                if (!trailerButton.length) return;

                trailerButton.off('hover:enter');

                trailerButton.on('hover:enter',
                    function () {
                        var menu = getTrailersMenu(yotubeVideos, Lampa.Storage.field('tmdb_lang'));

                        Lampa.Select.show({
                            title: Lampa.Lang.translate('title_trailers'),
                            items: menu,
                            onSelect: function (a) {
                                Lampa.Player.play(a);
                                Lampa.Player.playlist(menu.filter(v => !v.separator));
                            }
                        });
                    });
            });
    }

    if (window.appready) {
        start();
    } else {
        Lampa.Listener.follow('app', function (event) {
            if (event.type === 'ready') {
                start();
            }
        });
    }
})();