﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Shared;
using Shared.Engine;
using System;
using System.Buffers;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace YoutubeProxy;

public class YoutubeVideoProxy : ActionResult
{
    private readonly string _videoUrl;

    public YoutubeVideoProxy(string videoUrl)
    {
        _videoUrl = videoUrl;
    }

    public override async Task ExecuteResultAsync(ActionContext context)
    {
        var httpContext = context.HttpContext;
        var response = httpContext.Response;

        var proxyManager = YouTubeSettings.CreateProxyManager();

        var proxy = proxyManager.Get();

        var handler = Http.Handler(_videoUrl, proxy: proxy);
        var client = FrendlyHttp.HttpMessageClient("proxy", handler);

        try
        {
            var request = new HttpRequestMessage(HttpMethod.Get, _videoUrl);
            
            if (httpContext.Request.Headers.Range.Count > 0)
            {
                request.Headers.TryAddWithoutValidation("Range", httpContext.Request.Headers.Range.ToArray());
            }

            Http.DefaultRequestHeaders(_videoUrl, request,
                cookie: null,
                referer: "https://www.youtube.com/",
                headers: null);

            using var streamResponse = await client.SendAsync(
                request,
                HttpCompletionOption.ResponseHeadersRead,
                httpContext.RequestAborted);
  
            if (streamResponse.StatusCode == HttpStatusCode.RequestedRangeNotSatisfiable)
            {
                response.StatusCode = 416;
                var contentLength = streamResponse.Content.Headers.ContentLength ?? 0;
                response.Headers["Content-Range"] = $"bytes */{contentLength}";
                return;
            }

            if (!streamResponse.IsSuccessStatusCode &&
                streamResponse.StatusCode != HttpStatusCode.PartialContent)
            {
                response.StatusCode = (int)streamResponse.StatusCode;
                return;
            }

            await CopyProxyHttpResponse(httpContext, streamResponse);
            proxyManager.Success();
        }
        catch
        {
            proxyManager.Refresh();
            throw;
        }
    }

    private static async Task CopyProxyHttpResponse(HttpContext context, HttpResponseMessage responseMessage)
    {
        var response = context.Response;
        response.StatusCode = (int)responseMessage.StatusCode;
        
        if (responseMessage.StatusCode != HttpStatusCode.PartialContent)
        {
            response.ContentLength = responseMessage.Content.Headers.ContentLength;
        }

        foreach (var header in responseMessage.Headers)
        {
            if (header.Key.ToLower() is "transfer-encoding" or "connection" or
                "content-security-policy" or "content-disposition" or "content-length")
                continue;

            if (header.Key.ToLower().StartsWith("x-") ||
                header.Key.ToLower().StartsWith("alt-") ||
                header.Key.ToLower().StartsWith("access-control"))
                continue;

            response.Headers[header.Key] = string.Join(",", header.Value);
        }

        foreach (var header in responseMessage.Content.Headers)
        {
            if (header.Key.ToLower() is "content-length")
                continue;

            response.Headers[header.Key] = string.Join(",", header.Value);
        }

        await using var responseStream = await responseMessage.Content.ReadAsStreamAsync();

        var bunit = AppInit.conf.serverproxy?.buffering;
        if (bunit?.enable == true &&
           (responseMessage.Content.Headers.ContentLength > 40_000_000))
        {
            await CopyWithBuffering(context, responseStream, bunit);
        }
        else
        {
            await CopyDirect(context, responseStream);
        }
    }

    private static async Task CopyWithBuffering(HttpContext context, Stream responseStream, dynamic bunit)
    {
        var channel = Channel.CreateBounded<(byte[] Buffer, int Length)>(
            new BoundedChannelOptions(capacity: bunit.length)
            {
                FullMode = BoundedChannelFullMode.Wait,
                SingleWriter = true,
                SingleReader = true
            });

        var readTask = Task.Factory.StartNew(async () =>
        {
            try
            {
                while (!context.RequestAborted.IsCancellationRequested)
                {
                    byte[] chunkBuffer = ArrayPool<byte>.Shared.Rent(Math.Max(bunit.rent, 4096));
                    try
                    {
                        int bytesRead = await responseStream.ReadAsync(chunkBuffer, 0, chunkBuffer.Length, context.RequestAborted);
                        if (bytesRead == 0)
                        {
                            ArrayPool<byte>.Shared.Return(chunkBuffer);
                            break;
                        }
                        await channel.Writer.WriteAsync((chunkBuffer, bytesRead), context.RequestAborted);
                    }
                    catch
                    {
                        ArrayPool<byte>.Shared.Return(chunkBuffer);
                        break;
                    }
                }
            }
            finally
            {
                channel.Writer.Complete();
            }
        }, TaskCreationOptions.LongRunning);

        try
        {
            await foreach (var (buffer, length) in channel.Reader.ReadAllAsync(context.RequestAborted))
            {
                await context.Response.Body.WriteAsync(buffer, 0, length, context.RequestAborted);
                ArrayPool<byte>.Shared.Return(buffer);
            }
        }
        finally
        {
            await readTask;
        }
    }

    private static async Task CopyDirect(HttpContext context, Stream responseStream)
    {
        var buffer = ArrayPool<byte>.Shared.Rent(4096);
        try
        {
            int bytesRead;
            while ((bytesRead = await responseStream.ReadAsync(buffer, context.RequestAborted)) != 0)
            {
                await context.Response.Body.WriteAsync(buffer, 0, bytesRead, context.RequestAborted);
            }
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer);
        }
    }
}