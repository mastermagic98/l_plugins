﻿using Shared.Engine;
using Shared.Models.Module;
using System;

namespace YoutubeProxy;

public class ModInit
{
    public static string DirectoryPath { get; private set; }

    public const string Version = "1.2.2";

    public static void loaded(InitspaceModel initspace)
    {
        Console.WriteLine($"Youtube proxy v{Version}");

        YouTubeSettings.Instance = ModuleInvoke.Conf(
                YouTubeSettings.PluginName,
                new YouTubeSettings())
            .ToObject<YouTubeSettings>();

        DirectoryPath = initspace.path;
    }
}
