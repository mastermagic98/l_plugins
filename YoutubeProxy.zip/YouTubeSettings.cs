﻿using System.Collections.Generic;
using Shared.Engine;
using Shared.Models.Base;

namespace YoutubeProxy;

public class YouTubeSettings : BaseSettings
{
    public static string PluginName = "youtube";

    public static YouTubeSettings Instance;

    public List<string> geo { get; set; } = null;

    public int cache_time { get; set; } = 1440; // 1d

    public YouTubeSettings()
    {
        plugin = PluginName;
    }

    public static ProxyManager CreateProxyManager() => new(PluginName, Instance);
}
