using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Shared;
using Shared.Engine;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using YoutubeExplode;
using YoutubeExplode.Videos.Streams;

namespace YoutubeProxy.Controllers;

public class YoutubeController : BaseController
{
    [HttpGet]
    [AllowAnonymous]
    [Route("/youtube-proxy.js")]
    public IActionResult GetPlugin()
    {
        var pluginContent = FileCache.ReadAllText(ModInit.DirectoryPath + "/youtube-proxy.js");

        var geo = (YouTubeSettings.Instance.geo ?? new List<string>())
            .Select(x => x.ToUpper(CultureInfo.InvariantCulture));

        var strBuilder = new StringBuilder(pluginContent)
            .Replace("{host}", host)
            .Replace("{geo}", JsonSerializer.Serialize(geo))
            .Replace("{country}", requestInfo.Country)
            .Replace("{version}", ModInit.Version);

        return Content(strBuilder.ToString(), "application/javascript; charset=utf-8");
    }

    [HttpGet]
    [Route("/youtube/video.mp4")]
    public async Task<ActionResult> GetVideo(string vid)
    {
        if (string.IsNullOrWhiteSpace(vid))
        {
            return BadRequest("Invalid YouTube video ID.");
        }

        var memKey = $"youtube:video:{vid}";

        var init = await loadKit(YouTubeSettings.Instance);
        return await InvkSemaphore(init, memKey, async () =>
        {
            try
            {
                if (hybridCache.TryGetValue(memKey, out string url))
                {
                    return new YoutubeVideoProxy(url);
                }

                var proxyManager = YouTubeSettings.CreateProxyManager();
                var proxy = proxyManager.Get();
                var videoUrl = $"https://youtube.com/watch?v={vid}";

                var handler = Http.Handler(videoUrl, proxy: proxy);
                var httpClient = FrendlyHttp.HttpMessageClient("base", handler);

                var youtubeClient = new YoutubeClient(httpClient);

                var manifest = await youtubeClient.Videos.Streams.GetManifestAsync(videoUrl);
                var streamUrl = manifest.GetMuxedStreams()
                    .Where(s => s.Container == Container.Mp4)
                    .GetWithHighestVideoQuality()
                    ?.Url;
                

                proxyManager.Success();

                if (string.IsNullOrEmpty(streamUrl))
                {
                    return NotFound();
                }


                hybridCache.Set(memKey, streamUrl, GetVideoExpiration(streamUrl));

                return new YoutubeVideoProxy(streamUrl);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return StatusCode(502);
            }
        });
    }

    [HttpGet]
    [Route("/youtube/img.jpg")]
    public async Task<IActionResult> GetThumbnail(string vid)
    {
        if (string.IsNullOrWhiteSpace(vid))
        {
            return BadRequest("Invalid YouTube video ID.");
        }

        var memKey = $"youtube:thumbnail:{vid}";

        var init = await loadKit(YouTubeSettings.Instance);
        return await InvkSemaphore(init, memKey, async () =>
        {
            if (!hybridCache.TryGetValue(memKey, out byte[] imageData))
            {
                var url = $"https://img.youtube.com/vi/{vid}/default.jpg";

                var proxyManager = YouTubeSettings.CreateProxyManager();

                try
                {
                    var proxy = proxyManager.Get();
                    imageData = await Http.Download(url, proxy: proxy);

                    if (imageData is { Length: > 0 })
                    {
                        hybridCache.Set(memKey, imageData, cacheTime(init.cache_time));
                        proxyManager.Success();
                    }
                    else
                    {
                        proxyManager.Refresh();
                        return NotFound();
                    }
                }
                catch (Exception ex)
                {
                    proxyManager.Refresh();
                    Console.WriteLine(ex);
                    return StatusCode(502);
                }
            }

            if (imageData == null || imageData.Length == 0)
            {
                return NotFound();
            }

            return File(imageData, "image/jpeg");
        });
    }

    private TimeSpan GetVideoExpiration(string url)
    {
        var uri = new Uri(url);
        var query = QueryHelpers.ParseQuery(uri.Query);

        if (query.TryGetValue("expire", out var expireValue))
        {
            var unixExpire = long.Parse(expireValue!);

            var expireDate = DateTimeOffset.FromUnixTimeSeconds(unixExpire);
            var timeLeft = expireDate - DateTimeOffset.UtcNow;

            return timeLeft;
        }
        else
        {
            return TimeSpan.Zero;
        }
    }
}